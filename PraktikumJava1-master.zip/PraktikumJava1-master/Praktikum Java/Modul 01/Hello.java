public class Hello{
 public static void main (String[]args){
  System.out.println("Halo Dunia");
  System.out.println("Nama saya Muhammad Daffa Naufal");
 }
}